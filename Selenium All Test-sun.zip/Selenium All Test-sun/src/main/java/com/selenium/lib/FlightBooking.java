package com.selenium.lib;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverInfo;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.lib.ExcelData;

public class FlightBooking {

	WebDriver driver;

	@Test(dataProvider = "mydata")

	public void loginTest(String Email, String Password) throws InterruptedException {

		ExcelData excel = new ExcelData(
				"C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\TestDataFile\\TestData.xlsx");
		/*
		 * choose browser from External file.
		 */
		String browserName;
		browserName = excel.getData(0, 7, 1);

		if (browserName.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		} else if (browserName.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		} else if (browserName.equalsIgnoreCase("IE")) {
			driver = new InternetExplorerDriver();
		}

		driver.manage().window().maximize();
		String URL;
		URL = excel.getData(0, 6, 1);
		driver.get(URL);
		/*
		 * Login
		 */
		driver.findElement(By.id("authentication-link")).click();

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		driver.findElement(By.xpath("//*[@id=\"login-modal\"]/div/div/div[1]/div/section/div[3]/div[1]/div[3]"))
				.click();

		WebElement userName = driver.findElement(By.xpath("//*[@id=\"email\"]"));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		userName.sendKeys(Email);
		System.out.println("Entered Email: " + Email);

		WebElement password = driver.findElement(By.cssSelector("#password"));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		password.sendKeys(Password);
		System.out.println("Entered Password: " + Password);

		driver.findElement(By.xpath("//*[@id=\"login-modal\"]/div/div/div/div/div/div[1]/form/div[1]/div/div/button"))
				.click();

		Thread.sleep(5000);

		driver.findElement(By.xpath("//*[@id=\"fsc-trip-type-selector-one-way\"]")).click();

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		WebElement from = driver.findElement(By.xpath("//*[@id=\"fsc-origin-search\"]"));
		from.sendKeys("Hyderabad (HYD)");
		System.out.println("Hyderabad (HYD)");

		WebElement destinationPlace = driver.findElement(By.xpath("//*[@id=\"fsc-destination-search\"]"));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		destinationPlace.sendKeys("Bengaluru (BLR)");
		System.out.println("Bengaluru (BLR)");

		WebElement dateClick = driver.findElement(By.id("depart-fsc-datepicker-button"));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		dateClick.click();

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		WebElement date = driver.findElement(By.xpath(
				"//*[@id=\"depart-fsc-datepicker-popover\"]/div/div/div[2]/div/table/tbody/tr[5]/td[2]/button/span"));
		date.click();

		WebElement checkForNearAirport = driver.findElement(
				By.xpath("//*[@id=\"flights-search-controls-root\"]/div/div/form/div[2]/div[1]/div[1]/label/input"));
		checkForNearAirport.click();

		WebElement classTravellers = driver
				.findElement(By.xpath("//*[@id=\"CabinClassTravellersSelector_fsc-class-travellers-trigger__18yAY\"]"));
		classTravellers.click();

		WebElement increaseAdults = driver
				.findElement(By.xpath("//*[@id=\"cabin-class-travellers-popover\"]/div/div/div[2]/div/button[2]"));
		increaseAdults.click();

		WebElement decreaseChildCount = driver
				.findElement(By.xpath("//*[@id=\"cabin-class-travellers-popover\"]/div/div/div[2]/div/button[1]"));
		decreaseChildCount.click();

		WebElement done = driver.findElement(By.xpath("//*[@id=\"cabin-class-travellers-popover\"]/footer/button"));
		done.click();

		WebElement searchFlights = driver
				.findElement(By.xpath("//*[@id=\"flights-search-controls-root\"]/div/div/form/div[3]/button"));
		searchFlights.click();
		
		
		/*
		 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		 */
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.MINUTES);
/*
		WebElement stops = driver
				.findElement(By.xpath("//*[@id=\"stops_content\"]/div[3]/label/svg"));
		stops.click();
		
		WebElement slider = driver.findElement(By.xpath("//*[@id=\"departure-times_content\"]/div/div/div[4]"));
		Actions actions=new Actions(driver);
		actions.dragAndDropBy(slider, 370, 615).release().build().perform();
		slider.click();   */
		
		WebElement selectFlight = driver
				.findElement(By.xpath("//*[@id=\"app-root\"]/div[2]/div[2]/div[1]/div[3]/a/div/div[3]/div/button"));
		selectFlight.click();
		
		WebElement easyTrip = driver
				.findElement(By.xpath("//*[@id=\"details-modal\"]/div/div/div[1]/div[4]/div[2]/a"));
		easyTrip.click();
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.MINUTES);
		
		WebElement Booking = driver.findElement(By.xpath("WebElement continueBooking = driver.findElement(By.id(\"itineraryBtn\"));\r\n" + 
				"		continueBooking.click();"));
	    Booking.click();
		
		System.out.println(driver.getTitle());
	}

	@DataProvider(name = "mydata")
	public Object[][] passData() {
		// String InvalidUserName;
		// String validPasswordOne;
		// String validUserNameOne;
		// String InvalidPassword;
		String validUserName;
		String validPassword;

		ExcelData excel = new ExcelData(
				"C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\TestDataFile\\TestData.xlsx");

		validUserName = excel.getData(0, 0, 1);
		validPassword = excel.getData(0, 1, 1);

		// InvalidUserName = excel.getData(0, 2, 1);
		// validPasswordOne = excel.getData(0, 3, 1);

		// validUserNameOne = excel.getData(0, 4, 1);
		// InvalidPassword = excel.getData(0, 5, 1);

		Object[][] data = new Object[1][2];

		// data[0][0] = InvalidUserName;
		// data[0][1] = validPasswordOne;

		// data[1][0] = validUserNameOne;
		// data[1][1] = InvalidPassword;

		data[0][0] = validUserName;
		data[0][1] = validPassword;

		return data;
	}

	@AfterTest
	public void CheckBrowserOS() {
		// Get Browser name and version.
		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
		String browserName = caps.getBrowserName();
		String browserVersion = caps.getVersion();

		// Get OS name.
		String os = System.getProperty("os.name").toLowerCase();
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("OS = " + os + ", Browser = " + browserName + " " + browserVersion);
	}
}

/*
 * WebElement account =
 * driver.findElement(By.cssSelector("#login-button-nav-item"));
 * account.click();
 * 
 * //driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS); WebElement
 * accountqq = driver.findElement(By.xpath(
 * "//*[@id=\"profile-app\"]/main/div/div/div[1]/section/nav/div/li[3]/a/section"
 * )); accountqq.click(); driver.manage().timeouts().implicitlyWait(2,
 * TimeUnit.SECONDS); WebElement deleteAccount = driver.findElement(By.xpath(
 * "//*[@id=\"profile-app\"]/main/div/div/div[2]/div/section/section[4]/div[2]/nav/div/div/section"
 * )); deleteAccount.click();
 * 
 * WebElement deleteConfirm =
 * driver.findElement(By.xpath("//*[@id=\"delete-dialog\"]/div/button[2]"));
 * deleteConfirm.click();
 */

/*
 * 
 * @AfterTest public void CheckBrowserOS() { // Get Browser name and version.
 * Capabilities caps = ((RemoteWebDriver) driver).getCapabilities(); String
 * browserName = caps.getBrowserName(); String browserVersion =
 * caps.getVersion();
 * 
 * // Get OS name. String os = System.getProperty("os.name").toLowerCase();
 * System.out.println(" "); System.out.println(" "); System.out.println("OS = "
 * + os + ", Browser = " + browserName + " " + browserVersion); } }
 * 
 * 
 * WebElement experience = driver.findElement(By.xpath(
 * "//*[@id=\"flights-search-controls-root\"]/div/div/form/div[1]/div/label[2]/div"
 * )); experience.click(); System.out.println("User Selected : One way journey"
 * + experience.getAttribute("value"));
 * 
 * WebElement date = driver.findElement(By.xpath("//*[@id=\"datepicker\"]"));
 * date.sendKeys("07/19/2019"); System.out.println("Entered date Is :" +
 * date.getAttribute("value"));
 * 
 * WebElement profession =
 * driver.findElement(By.xpath("//*[@id=\"profession-1\"]"));
 * profession.click(); System.out.println("User's Profession Is :" +
 * profession.getAttribute("value"));
 * 
 * driver.findElement(By.className("input-file")).sendKeys(FilePath);
 * 
 * WebElement tool = driver.findElement(By.xpath("//*[@id=\"tool-2\"]"));
 * tool.click(); System.out.println("Entered Tool Is :" +
 * tool.getAttribute("value"));
 * 
 * Select country = new Select(driver.findElement(By.id("continents")));
 * country.selectByVisibleText("Australia"); Select commands = new
 * Select(driver.findElement(By.id("selenium_commands")));
 * commands.selectByVisibleText("Navigation Commands");
 * 
 * try { Thread.sleep(3000); } catch (InterruptedException e) {
 * 
 * e.printStackTrace(); }
 * 
 * WebElement submit = driver.findElement(By.xpath("//*[@id=\"submit\"]"));
 * submit.click(); System.out.println(" ");
 * System.out.println("All Data recorded and Submitted successfully."); }
 * 
 * 
 * @AfterTest public void CheckBrowserOS() { // Get Browser name and version.
 * Capabilities caps = ((RemoteWebDriver) driver).getCapabilities(); String
 * browserName = caps.getBrowserName(); String browserVersion =
 * caps.getVersion();
 * 
 * // Get OS name. String os = System.getProperty("os.name").toLowerCase();
 * System.out.println(" "); System.out.println(" "); System.out.println("OS = "
 * + os + ", Browser = " + browserName + " " + browserVersion); }
 * 
 * }
 */
