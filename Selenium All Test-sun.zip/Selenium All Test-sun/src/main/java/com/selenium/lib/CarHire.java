package com.selenium.lib;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.selenium.lib.ExcelData;

public class CarHire {

	WebDriver driver;

	@Test(dataProvider = "mydata")

	public void loginTest(String Email, String Password) throws InterruptedException {

		ExcelData excel = new ExcelData(
				"C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\TestDataFile\\TestData.xlsx");
		/*
		 * choose browser from External file.
		 */
		String browserName;
		browserName = excel.getData(0, 7, 1);

		if (browserName.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		} else if (browserName.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		} else if (browserName.equalsIgnoreCase("IE")) {
			driver = new InternetExplorerDriver();
		}

		driver.manage().window().maximize();
		String URL = excel.getData(0, 6, 1);
		driver.get(URL);

		/*
		 * Login
		 */
		driver.findElement(By.id("authentication-link")).click();

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		driver.findElement(By.xpath("//*[@id=\"login-modal\"]/div/div/div[1]/div/section/div[3]/div[1]/div[3]"))
				.click();

		WebElement userName = driver.findElement(By.xpath("//*[@id=\"email\"]"));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		userName.sendKeys(Email);
		System.out.println("Entered Email: " + Email);

		WebElement password = driver.findElement(By.cssSelector("#password"));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		password.sendKeys(Password);
		System.out.println("Entered Password: " + Password);

		driver.findElement(By.xpath("//*[@id=\"login-modal\"]/div/div/div/div/div/div[1]/form/div[1]/div/div/button"))
				.click();

		Thread.sleep(5000);

		driver.findElement(By.xpath("//*[@id=\"carhi\"]/span")).click();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		WebElement pickup = driver.findElement(By.id("carhire-search-controls-location-pick-up"));
		String pickupLocation = excel.getData(0, 9, 1);
		pickup.sendKeys(pickupLocation);

		System.out.println(pickupLocation);

		WebElement pickupClick = driver
				.findElement(By.xpath("//*[@id=\"react-autowhatever-1--item-0\"]/section/div/span"));
		pickupClick.click();

		WebElement checkDifferentPlace = driver
				.findElement(By.xpath("//*[@id=\"carhire-search-controls-different-drop-off-docked\"]"));
		checkDifferentPlace.click();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		WebElement dateClick = driver.findElement(By.xpath("//*[@id=\"carhire-search-controls-date-pick-up\"]"));
		dateClick.click();

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		WebElement date = driver.findElement(By.xpath(
				"//*[@id=\"carhire-search-controls-date-pick-up-popover\"]/div/div/div[2]/div/table[1]/tbody/tr[5]/td[2]/button"));
		date.click();

		WebElement pickUpTimeClick = driver.findElement(By.id("carhire-search-controls-time-pick-up"));
		pickUpTimeClick.click();

		WebElement pickUpTime = driver
				.findElement(By.xpath("//*[@id=\"carhire-search-controls-time-pick-up\"]/option[21]"));
		pickUpTime.click();

		WebElement DropOffDateClick = driver
				.findElement(By.xpath("//*[@id=\"carhire-search-controls-date-drop-off\"]"));
		DropOffDateClick.click();

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		WebElement DropOffDate = driver.findElement(By.xpath(
				"//*[@id=\"carhire-search-controls-date-drop-off-popover\"]/div/div/div[2]/div/table[1]/tbody/tr[5]/td[3]/button"));
		DropOffDate.click();

		WebElement DropOffTimeClick = driver.findElement(By.id("carhire-search-controls-time-drop-off"));
		DropOffTimeClick.click();

		WebElement DropOffTime = driver
				.findElement(By.xpath("//*[@id=\"carhire-search-controls-time-drop-off\"]/option[6]"));
		DropOffTime.click();

		WebElement searchFlights = driver.findElement(By.className("submit-container-2kvPF"));
		searchFlights.click();

		driver.manage().timeouts().implicitlyWait(4, TimeUnit.MINUTES);

		WebElement selectCar = driver.findElement(By.xpath("//*[@id=\"carhire-group-panel-button\"]"));
		selectCar.click();

		WebElement selectCarDeal = driver.findElement(By.xpath("//*[@id=\"carhire-deal-button\"]"));
		selectCarDeal.click();

		driver.manage().timeouts().implicitlyWait(4, TimeUnit.MINUTES);

		((JavascriptExecutor) driver).executeScript("document.body.style.zoom='40%' ");

		driver.manage().timeouts().implicitlyWait(4, TimeUnit.MINUTES);

		// WebElement firstNameClick = driver
		// .findElement(By.id("firstname"));
		// firstNameClick.click();

		// WebElement firstName = driver.findElement(By.id("firstname"));
		// firstName.sendKeys("Vishwanathan");

		/*
		 * 
		 * 
		 * WebElement increaseAdults = driver .findElement(By.xpath(
		 * "//*[@id=\"cabin-class-travellers-popover\"]/div/div/div[2]/div/button[2]"));
		 * increaseAdults.click();
		 * 
		 * WebElement decreaseChildCount = driver .findElement(By.xpath(
		 * "//*[@id=\"cabin-class-travellers-popover\"]/div/div/div[2]/div/button[1]"));
		 * decreaseChildCount.click();
		 * 
		 * WebElement done = driver.findElement(By.xpath(
		 * "//*[@id=\"cabin-class-travellers-popover\"]/footer/button")); done.click();
		 * 
		 * WebElement searchFlights = driver .findElement(By.xpath(
		 * "//*[@id=\"flights-search-controls-root\"]/div/div/form/div[3]/button"));
		 * searchFlights.click();
		 * 
		 * 
		 * /*
		 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		 * %%%%%
		 */
		// driver.manage().timeouts().implicitlyWait(3, TimeUnit.MINUTES);
		/*
		 * WebElement stops = driver
		 * .findElement(By.xpath("//*[@id=\"stops_content\"]/div[3]/label/svg"));
		 * stops.click();
		 * 
		 * WebElement slider = driver.findElement(By.xpath(
		 * "//*[@id=\"departure-times_content\"]/div/div/div[4]")); Actions actions=new
		 * Actions(driver); actions.dragAndDropBy(slider, 370,
		 * 615).release().build().perform(); slider.click();
		 * 
		 * WebElement selectFlight = driver .findElement(By.xpath(
		 * "//*[@id=\"app-root\"]/div[2]/div[2]/div[1]/div[3]/a/div/div[3]/div/button"))
		 * ; selectFlight.click();
		 * 
		 * WebElement easyTrip = driver .findElement(By.xpath(
		 * "//*[@id=\"details-modal\"]/div/div/div[1]/div[4]/div[2]/a"));
		 * easyTrip.click();
		 * 
		 * driver.manage().timeouts().implicitlyWait(3, TimeUnit.MINUTES);
		 * 
		 * WebElement Booking = driver.findElement(By.
		 * xpath("WebElement continueBooking = driver.findElement(By.id(\"itineraryBtn\"));\r\n"
		 * + "		continueBooking.click();")); Booking.click();
		 * 
		 */

		System.out.println(driver.getTitle());
	}

	@DataProvider(name = "mydata")
	public Object[][] passData() {
		// String InvalidUserName;
		// String validPasswordOne;
		// String validUserNameOne;
		// String InvalidPassword;
		String validUserName;
		String validPassword;

		ExcelData excel = new ExcelData(
				"C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\TestDataFile\\TestData.xlsx");

		validUserName = excel.getData(0, 0, 1);
		validPassword = excel.getData(0, 1, 1);

		// InvalidUserName = excel.getData(0, 2, 1);
		// validPasswordOne = excel.getData(0, 3, 1);

		// validUserNameOne = excel.getData(0, 4, 1);
		// InvalidPassword = excel.getData(0, 5, 1);

		Object[][] data = new Object[1][2];

		// data[0][0] = InvalidUserName;
		// data[0][1] = validPasswordOne;

		// data[1][0] = validUserNameOne;
		// data[1][1] = InvalidPassword;

		data[0][0] = validUserName;
		data[0][1] = validPassword;

		return data;
	}

	@AfterTest
	public void CheckBrowserOS() {
		// Get Browser name and version.
		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
		String browserName = caps.getBrowserName();
		String browserVersion = caps.getVersion();

		// Get OS name.
		String os = System.getProperty("os.name").toLowerCase();
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("OS = " + os + ", Browser = " + browserName + " " + browserVersion);
	}
}