package com.selenium.toolsqa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.selenium.lib.ExcelData;

public class DataFromExcel {
	
	WebDriver driver;
	
	@Test(dataProvider = "WebDriverData")
	public void loginTest(String FirstName,String LastName)
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\driver\\chromedriver.exe");
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.toolsqa.com/automation-practice-form/");
		
		WebElement userFirstName = driver.findElement(By.name("firstname"));
		userFirstName.sendKeys(FirstName);
		System.out.println("Entered User_FirstName Is: " + userFirstName.getAttribute("value"));

		WebElement userLastName = driver.findElement(By.name("lastname"));
		userLastName.sendKeys(LastName);
		System.out.println("Entered User_LastName Is: " + userLastName.getAttribute("value"));
		
		System.out.println(driver.getTitle());
		
	}
	@DataProvider(name="WebDriverData")
	public Object[][] passData()
	{
		ExcelData config=new ExcelData("C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\TestDataFile\\TestData.xlsx");
		int rows=config.getRowCount(0);
		
		
		Object[][] data=new Object[rows][2];
		for(int i=0;i<rows;i++)
		{
			data[i][0]=config.getData(0, i,0);
			data[i][1]=config.getData(0, i,1);
		}
		return data;
		
	}
	

}
