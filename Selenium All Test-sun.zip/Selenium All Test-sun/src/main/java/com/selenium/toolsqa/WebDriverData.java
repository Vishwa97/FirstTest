package com.selenium.toolsqa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class WebDriverData {
	
	WebDriver driver;
	
	@Test(dataProvider = "WebDriverData")
	public void loginTest(String FirstName,String LastName)
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\driver\\chromedriver.exe");
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.toolsqa.com/automation-practice-form/");
		
		WebElement userFirstName = driver.findElement(By.name("firstname"));
		userFirstName.sendKeys(FirstName);
		System.out.println("Entered User_FirstName Is: " + userFirstName.getAttribute("value"));

		WebElement userLastName = driver.findElement(By.name("lastname"));
		userLastName.sendKeys(LastName);
		System.out.println("Entered User_LastName Is: " + userLastName.getAttribute("value"));
		
		System.out.println(driver.getTitle());
		
	}
	@DataProvider(name="WebDriverData")
	public Object[][] passData()
	{
		Object[][] data=new Object[3][2];
		data[0][0]="Vishwanathan";
		data[0][1]="Mathesan";
		
		data[1][0]="Vishwa";
		data[1][1]="Mathe";
		
		data[2][0]="Vis";
		data[2][1]="Ma";
		
		return data;
		
	}
	

}
