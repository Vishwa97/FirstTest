package com.selenium.toolsqa;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.spi.ToolProvider;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class ToolsQaTest {
	
	WebDriver driver;
	@BeforeMethod
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		CheckBrowserOS();
		driver.get("https://www.toolsqa.com/automation-practice-form/");
		driver.manage().window().maximize();

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
	}

	public void CheckBrowserOS() {
		// Get Browser name and version.
		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
		String browserName = caps.getBrowserName();
		String browserVersion = caps.getVersion();

		// Get OS name.
		String os = System.getProperty("os.name").toLowerCase();
		System.out.println("OS = " + os + ", Browser = " + browserName + " " + browserVersion);
	}

	@Test
	public void Login() {

		WebElement userFirstName = driver.findElement(By.name("firstname"));
		userFirstName.sendKeys("Vishwanathan");
		System.out.println("Entered User_FirstName Is: " + userFirstName.getAttribute("value"));

		WebElement userLastName = driver.findElement(By.name("lastname"));
		userLastName.sendKeys("Mathesan");
		System.out.println("Entered User_LastName Is: " + userLastName.getAttribute("value"));

		WebElement Sex = driver.findElement(By.id("sex-0"));
		Sex.click();
		System.out.println("User Gender Is :" + Sex.getAttribute("value"));

		WebElement experience = driver.findElement(By.id("exp-1"));
		experience.click();
		System.out.println("User Experience :" + experience.getAttribute("value"));

		WebElement date = driver.findElement(By.xpath("//*[@id=\"datepicker\"]"));
		date.sendKeys("07/18/2019");
		System.out.println("Entered date Is :" + date.getAttribute("value"));

		WebElement profession = driver.findElement(By.xpath("//*[@id=\"profession-1\"]"));
		profession.click();
		System.out.println("User's Profession Is :" + profession.getAttribute("value"));

		driver.findElement(By.className("input-file"))
				.sendKeys("C:\\Users\\Vishwanathan.M\\Desktop\\EmployeeFile.html");

		WebElement tool = driver.findElement(By.xpath("//*[@id=\"tool-2\"]"));
		tool.click();
		System.out.println("Entered Tool Is :" + tool.getAttribute("value"));

		Select country = new Select(driver.findElement(By.id("continents")));
		country.selectByVisibleText("Australia");
		Select commands = new Select(driver.findElement(By.id("selenium_commands")));
		commands.selectByVisibleText("Navigation Commands");

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

		WebElement submit = driver.findElement(By.xpath("//*[@id=\"submit\"]"));
		submit.click();
		System.out.println(" ");
		System.out.println("All Data recorded and Submitted successfully.");
	}
}



