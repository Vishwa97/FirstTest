package com.selenium.toolsqa;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestData {
	 XSSFWorkbook wb;
	 XSSFSheet sheet1;
	public TestData(String excelPath) {
		try {
			File src = new File("C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\TestDataFile\\TestData.xlsx");
			FileInputStream fis = new FileInputStream(src);
			wb = new XSSFWorkbook(fis);

			//XSSFSheet sheet1 = wb.getSheetAt(0);
			//String dataOne = sheet1.getRow(0).getCell(0).getStringCellValue();
			//System.out.println("Data is: " + dataOne);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
	public String getData(int sheetNumber,int row,int column)
	{
		sheet1=wb.getSheetAt(sheetNumber);
		String data=sheet1.getRow(row).getCell(column).getStringCellValue();
		return data;
	}
	public int getRowCount(int sheetIndex)
	{
		int row=wb.getSheetAt(sheetIndex).getLastRowNum();
		row=row+1;
		return row;
	}

}
