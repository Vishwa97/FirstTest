package com.selenium.lib;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverInfo;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import com.selenium.lib.ExcelData;

public class CrossBrowser {

	WebDriver driver;

	@Test(dataProvider = "mydata")
	

	public void loginTest(String Email, String Password) throws InterruptedException {
		
		ExcelData excel = new ExcelData(
				"C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\TestDataFile\\TestData.xlsx");
        /*
         * choose browser from External file.
         */
		String browserName;
		browserName = excel.getData(0, 7, 1);
		
		if (browserName.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		} else if (browserName.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		} else if (browserName.equalsIgnoreCase("IE")) {
			driver = new InternetExplorerDriver();
		}
		
		driver.manage().window().maximize();
		String URL;
		URL = excel.getData(0, 6, 1);
		driver.get(URL);
		/*
		 * Login
		 */
		driver.findElement(By.id("authentication-link")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"login-modal\"]/div/div/div[1]/div/section/div[3]/div[1]/div[3]"))
				.click();

		WebElement userName = driver.findElement(By.xpath("//*[@id=\"email\"]"));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		userName.sendKeys(Email);
		System.out.println("Entered Email: " + Email);

		WebElement password = driver.findElement(By.cssSelector("#password"));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		password.sendKeys(Password);
		System.out.println("Entered Password: " + Password);

		driver.findElement(By.xpath("//*[@id=\"login-modal\"]/div/div/div/div/div/div[1]/form/div[1]/div/div/button"))
				.click();

		Thread.sleep(5000);
		System.out.println(driver.getTitle());
	}

	@DataProvider(name = "mydata")
	public Object[][] passData() {
		String InvalidUserName;
		String validPasswordOne;
		String validUserNameOne;
		String InvalidPassword;
		String validUserName;
		String validPassword;

		ExcelData excel = new ExcelData(
				"C:\\Users\\Vishwanathan.M\\Downloads\\My Projects\\New folder\\eclipse-jee-2019-03-R-win32-x86_64\\Selenium_WebDriver_ToolsQa\\TestDataFile\\TestData.xlsx");

		validUserName = excel.getData(0, 0, 1);
		validPassword = excel.getData(0, 1, 1);

		InvalidUserName = excel.getData(0, 2, 1);
		validPasswordOne = excel.getData(0, 3, 1);

		validUserNameOne = excel.getData(0, 4, 1);
		InvalidPassword = excel.getData(0, 5, 1);
		

		Object[][] data = new Object[3][2];

		data[0][0] = InvalidUserName;
		data[0][1] = validPasswordOne;

		data[1][0] = validUserNameOne;
		data[1][1] = InvalidPassword;

		data[2][0] = validUserName;
		data[2][1] = validPassword;
		

		return data;
	}
	@AfterTest
	public void CheckBrowserOS() {
		// Get Browser name and version.
		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
		String browserName = caps.getBrowserName();
		String browserVersion = caps.getVersion();

		// Get OS name.
		String os = System.getProperty("os.name").toLowerCase();
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("OS = " + os + ", Browser = " + browserName + " " + browserVersion);
	}
}










/*
 * WebElement account =
 * driver.findElement(By.cssSelector("#login-button-nav-item"));
 * account.click();
 * 
 * //driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS); WebElement
 * accountqq = driver.findElement(By.xpath(
 * "//*[@id=\"profile-app\"]/main/div/div/div[1]/section/nav/div/li[3]/a/section"
 * )); accountqq.click(); driver.manage().timeouts().implicitlyWait(2,
 * TimeUnit.SECONDS); WebElement deleteAccount = driver.findElement(By.xpath(
 * "//*[@id=\"profile-app\"]/main/div/div/div[2]/div/section/section[4]/div[2]/nav/div/div/section"
 * )); deleteAccount.click();
 * 
 * WebElement deleteConfirm =
 * driver.findElement(By.xpath("//*[@id=\"delete-dialog\"]/div/button[2]"));
 * deleteConfirm.click();
 */

/*
 * 
 * @AfterTest public void CheckBrowserOS() { // Get Browser name and version.
 * Capabilities caps = ((RemoteWebDriver) driver).getCapabilities(); String
 * browserName = caps.getBrowserName(); String browserVersion =
 * caps.getVersion();
 * 
 * // Get OS name. String os = System.getProperty("os.name").toLowerCase();
 * System.out.println(" "); System.out.println(" "); System.out.println("OS = "
 * + os + ", Browser = " + browserName + " " + browserVersion); } }
 * 
 * 
 * WebElement experience = driver.findElement(By.xpath(
 * "//*[@id=\"flights-search-controls-root\"]/div/div/form/div[1]/div/label[2]/div"
 * )); experience.click(); System.out.println("User Selected : One way journey"
 * + experience.getAttribute("value"));
 * 
 * WebElement date = driver.findElement(By.xpath("//*[@id=\"datepicker\"]"));
 * date.sendKeys("07/19/2019"); System.out.println("Entered date Is :" +
 * date.getAttribute("value"));
 * 
 * WebElement profession =
 * driver.findElement(By.xpath("//*[@id=\"profession-1\"]"));
 * profession.click(); System.out.println("User's Profession Is :" +
 * profession.getAttribute("value"));
 * 
 * driver.findElement(By.className("input-file")).sendKeys(FilePath);
 * 
 * WebElement tool = driver.findElement(By.xpath("//*[@id=\"tool-2\"]"));
 * tool.click(); System.out.println("Entered Tool Is :" +
 * tool.getAttribute("value"));
 * 
 * Select country = new Select(driver.findElement(By.id("continents")));
 * country.selectByVisibleText("Australia"); Select commands = new
 * Select(driver.findElement(By.id("selenium_commands")));
 * commands.selectByVisibleText("Navigation Commands");
 * 
 * try { Thread.sleep(3000); } catch (InterruptedException e) {
 * 
 * e.printStackTrace(); }
 * 
 * WebElement submit = driver.findElement(By.xpath("//*[@id=\"submit\"]"));
 * submit.click(); System.out.println(" ");
 * System.out.println("All Data recorded and Submitted successfully."); }
 * 
 * 
 * @AfterTest public void CheckBrowserOS() { // Get Browser name and version.
 * Capabilities caps = ((RemoteWebDriver) driver).getCapabilities(); String
 * browserName = caps.getBrowserName(); String browserVersion =
 * caps.getVersion();
 * 
 * // Get OS name. String os = System.getProperty("os.name").toLowerCase();
 * System.out.println(" "); System.out.println(" "); System.out.println("OS = "
 * + os + ", Browser = " + browserName + " " + browserVersion); }
 * 
 * }
 */
